namespace UI.Panels
{
    using System.Collections.Generic;
    using Game;
    using Game.Data.Business;
    using Game.Data.Upgrade;
    using TMPro;
    using UnityEngine;
    using UnityEngine.UI;
    
    public class BusinessPanelView : MonoBehaviour
    {
        [Header("Texts")] 
        [SerializeField] private TMP_Text businessNameText;
        [SerializeField] private TMP_Text levelText;
        [SerializeField] private TMP_Text incomeText;
        [SerializeField] private TMP_Text buyLevelPriceText;

        [Header("Progress")] 
        [SerializeField] private Image progressBar;

        [Header("Buttons")] 
        [SerializeField] private Button buyLevelButton;

        [Header("UI Blocks")] 
        [SerializeField] private RectTransform lockedPanel;

        [Header("Upgrades")] 
        [SerializeField] private UpgradePanelView upgradePanelView;

        public void Init(BusinessId businessId, string displayName, IReadOnlyList<UpgradeConfigData> upgrades)
        {
            businessNameText.text = displayName;
            upgradePanelView.Init(upgrades, businessId);

            buyLevelButton.onClick.RemoveAllListeners();
            buyLevelButton.onClick.AddListener(() => { EcsUiEventBridge.Instance.SendBuyLevelEvent(businessId); });
        }

        public void SetProgress(float progress)
        {
            progressBar.fillAmount = progress;
        }

        public void UpdateStatic(
            int level,
            long income,
            bool isUnlocked,
            long buyLevelPrice,
            IReadOnlyList<UpgradeConfigData> upgrades,
            bool[] upgradesBought,
            bool[] canBuyUpgrade,
            bool canBuyLevel)
        {
            levelText.text = level.ToString();
            incomeText.text = $"+{income}";
            buyLevelPriceText.text = buyLevelPrice.ToString();

            lockedPanel.gameObject.SetActive(!isUnlocked);
            buyLevelButton.interactable = canBuyLevel;

            upgradePanelView.UpdateItems(upgrades, upgradesBought, canBuyUpgrade);
        }
    }
}