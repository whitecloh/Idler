namespace UI
{
    using System.Collections.Generic;
    using Game.Data.Business;
    using Game.Data.Upgrade;
    using Controllers;
    using Elements;
    using UnityEngine;
    
    public class HUDController : MonoBehaviour
    {
        [SerializeField] private BalanceView balanceView;
        [SerializeField] private BusinessController businessController;
        public static HUDController Instance { get; private set; }

        public void Init()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
            }

            Instance = this;
            businessController.Init();
        }

        public void SetBalance(long value)
        {
            balanceView.SetBalance(value);
        }

        public void UpdateBusinessPanelProgress(BusinessId id, float progress)
        {
            businessController.UpdateProgress(id, progress);
        }

        public void UpdateBusinessPanelStatic(
            BusinessId id, int level, long income, bool isUnlocked,
            long buyLevelPrice, IReadOnlyList<UpgradeConfigData> upgrades,
            bool[] upgradesBought, bool canBuyLevel, bool[] canBuyUpgrade)
        {
            businessController.UpdateStatic(id, level, income, isUnlocked, buyLevelPrice,
                upgrades, upgradesBought, canBuyLevel, canBuyUpgrade);
        }
    }
}