namespace Game
{
    using Components;
    using Events;
    using Save;
    using Services;
    using Systems;
    using Leopotam.EcsLite;
    using UI;
    using UnityEngine;
    
    public class EcsStartup : MonoBehaviour
    {
        [Header("Dependencies")] [SerializeField]
        private ConfigService configService;

        [SerializeField] private HUDController hudController;
        [SerializeField] private EcsUiEventBridge ecsUiEventBridge;

        private SaveData _loadedSaveData;
        private IEcsSystems _systems;
        private EcsWorld _world;

        private void Awake()
        {
            configService.Init();
            hudController.Init();

            _loadedSaveData = SaveService.Load();

            _world = new EcsWorld();
            _systems = new EcsSystems(_world);

            ecsUiEventBridge.Init(_world);

            _systems
                .Add(new BuyLevelSystem())
                .Add(new UpgradeSystem())
                .Add(new RecalculateBusinessIncomeSystem())
                .Add(new IncomeSystem())
                .Add(new SaveSystem())
                .Add(new UIProgressSystem())
                .Add(new UIEventsSystem());

            InitializeEntitiesFromSave(_loadedSaveData);

            _systems.Init();

            EmitInitialUiEvents();
        }

        private void Update()
        {
            _systems?.Run();
        }

        private void OnDestroy()
        {
            _systems?.Destroy();
            _systems = null;
            _world?.Destroy();
            _world = null;
        }

        private void OnApplicationPause(bool pause)
        {
            if (pause)
                ForceSave();
        }

        private void OnApplicationQuit()
        {
            ForceSave();
        }

        private void InitializeEntitiesFromSave(SaveData saveData)
        {
            var playerEntity = _world.NewEntity();
            ref var balance = ref _world.GetPool<BalanceComponent>().Add(playerEntity);
            balance.Value = saveData.Balance;

            foreach (var bizId in configService.GetAllBusinessIds())
            {
                var bizSave = saveData.Businesses[bizId];
                var businessEntity = _world.NewEntity();
                ref var business = ref _world.GetPool<BusinessComponent>().Add(businessEntity);
                business.BusinessId = bizId;
                business.Level = bizSave.Level;

                ref var progress = ref _world.GetPool<IncomeProgressComponent>().Add(businessEntity);
                progress.Progress = bizSave.Progress;
                progress.Delay = configService.GetIncomeDelay(bizId);

                var upgradeConfigs = configService.GetUpgradeConfigs(bizId);
                for (var i = 0; i < upgradeConfigs.Count; i++)
                {
                    var upgradeEntity = _world.NewEntity();
                    ref var upgrade = ref _world.GetPool<UpgradeComponent>().Add(upgradeEntity);
                    upgrade.BusinessId = bizId;
                    upgrade.Index = i;
                    upgrade.IsActive = bizSave.Upgrades[i].IsActive;
                    upgrade.Multiplier = upgradeConfigs[i].IncomeMultiplier;
                }

                var recalcEventEntity = _world.NewEntity();
                ref var recalcEvent = ref _world.GetPool<RecalculateIncomeEvent>().Add(recalcEventEntity);
                recalcEvent.BusinessId = bizId;
            }
        }

        private void ForceSave()
        {
            if (_systems == null)
                return;

            var saveEntity = _world.NewEntity();
            _world.GetPool<SaveEvent>().Add(saveEntity);
            _systems.Run();
        }

        private void EmitInitialUiEvents()
        {
            var balanceChangeEntity = _world.NewEntity();
            _world.GetPool<BalanceChangedEvent>().Add(balanceChangeEntity);
            foreach (var businessId in configService.GetAllBusinessIds())
            {
                var entity = _world.NewEntity();
                ref var business = ref _world.GetPool<BusinessStateChangedEvent>().Add(entity);
                business.BusinessId = businessId;
            }

            _systems.Run();
        }
    }
}