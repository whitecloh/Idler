namespace Game.Systems
{
    using Components;
    using Data.Business;
    using Events;
    using Services;
    using Leopotam.EcsLite;
    
    public class BuyLevelSystem : IEcsRunSystem, IEcsInitSystem
    {
        private EcsPool<BalanceChangedEvent> _balanceChangedPool;

        private int _balanceEntity = -1;
        private EcsFilter _balanceFilter;
        private EcsPool<BalanceComponent> _balancePool;
        private EcsPool<BusinessStateChangedEvent> _bizChangedPool;
        private EcsFilter _businessFilter;
        private EcsPool<BusinessComponent> _businessPool;
        private EcsFilter _buyEventFilter;

        private EcsPool<BuyLevelEvent> _buyEventPool;
        private EcsPool<RecalculateIncomeEvent> _recalcPool;

        public void Init(IEcsSystems systems)
        {
            var world = systems.GetWorld();

            _buyEventFilter = world.Filter<BuyLevelEvent>().End();
            _businessFilter = world.Filter<BusinessComponent>().End();
            _balanceFilter = world.Filter<BalanceComponent>().End();

            _buyEventPool = world.GetPool<BuyLevelEvent>();
            _businessPool = world.GetPool<BusinessComponent>();
            _balancePool = world.GetPool<BalanceComponent>();
            _recalcPool = world.GetPool<RecalculateIncomeEvent>();
            _balanceChangedPool = world.GetPool<BalanceChangedEvent>();
            _bizChangedPool = world.GetPool<BusinessStateChangedEvent>();

            foreach (var e in _balanceFilter)
            {
                _balanceEntity = e;
                break;
            }
        }

        public void Run(IEcsSystems systems)
        {
            var world = systems.GetWorld();
            if (_balanceEntity < 0)
                return;

            foreach (var ev in _buyEventFilter)
            {
                ref var buy = ref _buyEventPool.Get(ev);
                
                var businessEntity = FindBusinessEntity(buy.BusinessId);
                if (businessEntity < 0)
                {
                    world.DelEntity(ev);
                    continue;
                }

                ref var business = ref _businessPool.Get(businessEntity);
                
                var price = ConfigService.Instance.GetLevelPrice(business.BusinessId, business.Level);

                ref var balance = ref _balancePool.Get(_balanceEntity);
                if (balance.Value >= price)
                {
                    balance.Value -= price;
                    business.Level++;
                    
                    var r = world.NewEntity();
                    ref var recalc = ref _recalcPool.Add(r);
                    recalc.BusinessId = business.BusinessId;
                    
                    _balanceChangedPool.Add(world.NewEntity());
                    ref var changed = ref _bizChangedPool.Add(world.NewEntity());
                    changed.BusinessId = business.BusinessId;
                }

                world.DelEntity(ev);
            }
        }

        private int FindBusinessEntity(BusinessId id)
        {
            foreach (var e in _businessFilter)
            {
                ref var b = ref _businessPool.Get(e);
                if (b.BusinessId == id) return e;
            }

            return -1;
        }
    }
}