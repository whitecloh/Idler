namespace Game.Systems
{
    using Components;
    using Leopotam.EcsLite;
    using UI;
    
    public class UIProgressSystem : IEcsRunSystem, IEcsInitSystem
    {
        private EcsPool<BusinessComponent> _businessPool;
        private EcsFilter _filter;
        private EcsPool<IncomeProgressComponent> _progressPool;

        public void Init(IEcsSystems systems)
        {
            var world = systems.GetWorld();
            _filter = world.Filter<BusinessComponent>()
                .Inc<IncomeProgressComponent>()
                .End();

            _businessPool = world.GetPool<BusinessComponent>();
            _progressPool = world.GetPool<IncomeProgressComponent>();
        }

        public void Run(IEcsSystems systems)
        {
            foreach (var e in _filter)
            {
                ref var business = ref _businessPool.Get(e);
                ref var progress = ref _progressPool.Get(e);

                var fill = business.Level > 0 ? progress.Progress : 0f;
                HUDController.Instance.UpdateBusinessPanelProgress(business.BusinessId, fill);
            }
        }
    }
}