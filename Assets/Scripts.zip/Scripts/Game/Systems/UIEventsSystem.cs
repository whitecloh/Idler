namespace Game.Systems
{
    using Components;
    using Data.Business;
    using Events;
    using Services;
    using Leopotam.EcsLite;
    using UI;
    using UnityEngine;
    using Utils;
    
    public class UIEventsSystem : IEcsRunSystem, IEcsInitSystem
    {
        private EcsFilter _balanceChangedFilter;

        private EcsFilter _balanceFilter;

        private EcsPool<BalanceComponent> _balancePool;
        private EcsFilter _businessChangedFilter;
        private EcsPool<BusinessStateChangedEvent> _businessChangedPool;
        private EcsFilter _businessFilter;
        private EcsPool<BusinessComponent> _businessPool;
        private EcsPool<IncomeComponent> _incomePool;
        private EcsFilter _upgradeFilter;
        private EcsPool<UpgradeComponent> _upgradePool;
        
        private int _balanceEntity = -1;

        public void Init(IEcsSystems systems)
        {
            var world = systems.GetWorld();

            _balanceChangedFilter = world.Filter<BalanceChangedEvent>().End();
            _businessChangedFilter = world.Filter<BusinessStateChangedEvent>().End();

            _balanceFilter = world.Filter<BalanceComponent>().End();
            _businessFilter = world.Filter<BusinessComponent>().End();
            _upgradeFilter = world.Filter<UpgradeComponent>().End();

            _balancePool = world.GetPool<BalanceComponent>();
            _businessPool = world.GetPool<BusinessComponent>();
            _incomePool = world.GetPool<IncomeComponent>();

            _businessChangedPool = world.GetPool<BusinessStateChangedEvent>();
            _upgradePool = world.GetPool<UpgradeComponent>();
            
            foreach (var e in _balanceFilter) 
            { 
                _balanceEntity = e; 
                break; 
            }
        }

        public void Run(IEcsSystems systems)
        {
            var world = systems.GetWorld();
            var config = ConfigService.Instance;
            
            var playerBalance = 0L;
            if (_balanceEntity >= 0)
                playerBalance = _balancePool.Get(_balanceEntity).Value;

            if (_balanceChangedFilter.GetEntitiesCount() > 0)
            {
                HUDController.Instance.SetBalance(playerBalance);

                foreach (var e in _businessFilter)
                {
                    ref var b = ref _businessPool.Get(e);
                    UpdateBusinessStatic(world, config, b.BusinessId, playerBalance);
                }

                foreach (var e in _balanceChangedFilter) world.DelEntity(e);
            }

            foreach (var ev in _businessChangedFilter)
            {
                var id = _businessChangedPool.Get(ev).BusinessId;
                UpdateBusinessStatic(world, config, id, playerBalance);
                world.DelEntity(ev);
            }
        }

        private void UpdateBusinessStatic(EcsWorld world, ConfigService config, BusinessId id, long playerBalance)
        {
            var entity = -1;
            foreach (var e in _businessFilter)
            {
                ref var b = ref _businessPool.Get(e);
                if (b.BusinessId == id) { entity = e; break; }
            }
            if (entity < 0) return;

            ref var business = ref _businessPool.Get(entity);
            var level = business.Level;
            var isUnlocked = level > 0;

            var levelPrice = config.GetLevelPrice(id, level);

            var income = 0L;
            if (isUnlocked)
            {
                if (_incomePool.Has(entity))
                {
                    income = _incomePool.Get(entity).Value;
                }
                else
                {
                    var baseIncome = config.GetBaseIncome(id);
                    var mult = EcsBusinessUtils.CalculateTotalUpgradeMultiplier(world, _upgradePool, id);
                    income = (long)Mathf.Round(level * baseIncome * (1f + mult));
                }
            }

            var upgrades = config.GetUpgradeConfigs(id);
            var upgradesBought = new bool[upgrades.Count];
            var canBuyUpgrade = new bool[upgrades.Count];

            foreach (var ue in _upgradeFilter)
            {
                ref var up = ref _upgradePool.Get(ue);
                if (up.BusinessId == id && up.Index >= 0 && up.Index < upgrades.Count)
                {
                    upgradesBought[up.Index] = up.IsActive;
                    canBuyUpgrade[up.Index] =
                        isUnlocked && !up.IsActive &&
                        playerBalance >= config.GetUpgradePrice(id, up.Index);
                }
            }

            var canBuyLevel = playerBalance >= levelPrice;
            if (!isUnlocked) income = 0L;

            HUDController.Instance.UpdateBusinessPanelStatic(
                id, level, income, isUnlocked, levelPrice,
                upgrades, upgradesBought, canBuyLevel, canBuyUpgrade);
        }
    }
}