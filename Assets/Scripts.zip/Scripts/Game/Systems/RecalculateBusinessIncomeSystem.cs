namespace Game.Systems
{
    using Components;
    using Events;
    using Services;
    using Leopotam.EcsLite;
    using UnityEngine;
    using Utils;
    
    public class RecalculateBusinessIncomeSystem : IEcsRunSystem, IEcsInitSystem
    {
        private EcsFilter _recalcFilter;
        private EcsFilter _businessFilter;

        private EcsPool<RecalculateIncomeEvent> _recalcPool;
        private EcsPool<BusinessComponent> _businessPool;
        private EcsPool<UpgradeComponent> _upgradePool;
        private EcsPool<IncomeComponent> _incomePool;
        
        public void Init(IEcsSystems systems)
        {
            var world = systems.GetWorld();
            _recalcFilter = world.Filter<RecalculateIncomeEvent>().End();
            _businessFilter = world.Filter<BusinessComponent>().End();

            _recalcPool = world.GetPool<RecalculateIncomeEvent>();
            _businessPool = world.GetPool<BusinessComponent>();
            _upgradePool = world.GetPool<UpgradeComponent>();
            _incomePool = world.GetPool<IncomeComponent>();
        }
        
        public void Run(IEcsSystems systems)
        {
            var world = systems.GetWorld();

            foreach (var ev in _recalcFilter)
            {
                var businessId = _recalcPool.Get(ev).BusinessId;

                foreach (var bizEntity in _businessFilter)
                {
                    ref var biz = ref _businessPool.Get(bizEntity);
                    if (biz.BusinessId != businessId || biz.Level <= 0)
                        continue;

                    var baseIncome = ConfigService.Instance.GetBaseIncome(businessId);
                    var multiplier = EcsBusinessUtils.CalculateTotalUpgradeMultiplier(world, _upgradePool, businessId);
                    var rawIncome = biz.Level * baseIncome * (1f + multiplier);
                    var income = (long)Mathf.Round(rawIncome);

                    if (_incomePool.Has(bizEntity))
                        _incomePool.Get(bizEntity).Value = income;
                    else
                        _incomePool.Add(bizEntity).Value = income;
                }

                world.DelEntity(ev);
            }
        }
    }
}