namespace Game.Systems
{
    using Components;
    using Data.Business;
    using Events;
    using Services;
    using Leopotam.EcsLite;
    
    public class UpgradeSystem : IEcsRunSystem, IEcsInitSystem
    {
        private EcsPool<BalanceChangedEvent> _balanceChangedPool;

        private int _balanceEntity = -1;
        private EcsFilter _balanceFilter;
        private EcsPool<BalanceComponent> _balancePool;
        private EcsPool<BusinessStateChangedEvent> _bizChangedPool;
        private EcsPool<RecalculateIncomeEvent> _recalcPool;
        private EcsFilter _upgradeEventFilter;

        private EcsPool<UpgradeEvent> _upgradeEventPool;
        private EcsFilter _upgradeFilter;
        private EcsPool<UpgradeComponent> _upgradePool;

        public void Init(IEcsSystems systems)
        {
            var world = systems.GetWorld();

            _upgradeEventFilter = world.Filter<UpgradeEvent>().End();
            _upgradeFilter = world.Filter<UpgradeComponent>().End();
            _balanceFilter = world.Filter<BalanceComponent>().End();

            _upgradeEventPool = world.GetPool<UpgradeEvent>();
            _upgradePool = world.GetPool<UpgradeComponent>();
            _balancePool = world.GetPool<BalanceComponent>();
            _recalcPool = world.GetPool<RecalculateIncomeEvent>();
            _balanceChangedPool = world.GetPool<BalanceChangedEvent>();
            _bizChangedPool = world.GetPool<BusinessStateChangedEvent>();

            foreach (var e in _balanceFilter)
            {
                _balanceEntity = e;
                break;
            }
        }

        public void Run(IEcsSystems systems)
        {
            var world = systems.GetWorld();
            if (_balanceEntity < 0)
                return;

            foreach (var ev in _upgradeEventFilter)
            {
                ref var upEv = ref _upgradeEventPool.Get(ev);
                
                var upgradeEntity = FindUpgradeEntity(upEv.BusinessId, upEv.UpgradeIndex);
                if (upgradeEntity >= 0)
                {
                    ref var up = ref _upgradePool.Get(upgradeEntity);
                    if (!up.IsActive)
                    {
                        var price = ConfigService.Instance.GetUpgradePrice(up.BusinessId, up.Index);
                        ref var balance = ref _balancePool.Get(_balanceEntity);

                        if (balance.Value >= price)
                        {
                            balance.Value -= price;
                            up.IsActive = true;
                            
                            var r = world.NewEntity();
                            ref var recalc = ref _recalcPool.Add(r);
                            recalc.BusinessId = up.BusinessId;
                            
                            _balanceChangedPool.Add(world.NewEntity());
                            ref var changed = ref _bizChangedPool.Add(world.NewEntity());
                            changed.BusinessId = up.BusinessId;
                        }
                    }
                }

                world.DelEntity(ev);
            }
        }

        private int FindUpgradeEntity(BusinessId id, int index)
        {
            foreach (var e in _upgradeFilter)
            {
                ref var u = ref _upgradePool.Get(e);
                if (u.BusinessId == id && u.Index == index)
                    return e;
            }

            return -1;
        }
    }
}