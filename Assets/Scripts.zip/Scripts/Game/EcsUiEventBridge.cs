namespace Game
{
    using Data.Business;
    using Events;
    using Leopotam.EcsLite;
    using UnityEngine;
    
    public class EcsUiEventBridge : MonoBehaviour
    {
        private EcsWorld _world;
        public static EcsUiEventBridge Instance { get; private set; }

        public void Init(EcsWorld world)
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
            }

            Instance = this;
            _world = world;
        }

        public void SendBuyLevelEvent(BusinessId businessId)
        {
            var entity = _world.NewEntity();
            ref var e = ref _world.GetPool<BuyLevelEvent>().Add(entity);
            e.BusinessId = businessId;
        }

        public void SendUpgradeEvent(BusinessId businessId, int upgradeIndex)
        {
            var entity = _world.NewEntity();
            ref var e = ref _world.GetPool<UpgradeEvent>().Add(entity);
            e.BusinessId = businessId;
            e.UpgradeIndex = upgradeIndex;
        }
    }
}